package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityFromJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityFromJdbcApplication.class, args);
	}

}

package com.wipro;

public interface userDAO {
    void saveUser(user user);
}
INSERT INTO employees(name, role) VALUES ('Alice', 'Developer');
INSERT INTO employees(name, role) VALUES ('Bob', 'Tester');
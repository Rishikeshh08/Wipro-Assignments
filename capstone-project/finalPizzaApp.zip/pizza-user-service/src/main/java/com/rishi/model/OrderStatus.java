package com.rishi.model;

public enum OrderStatus {
	PLACED, ACCEPTED, REJECTED, CANCELLED, PREPARING, OUT_FOR_DELIVERY, DELIVERED
}

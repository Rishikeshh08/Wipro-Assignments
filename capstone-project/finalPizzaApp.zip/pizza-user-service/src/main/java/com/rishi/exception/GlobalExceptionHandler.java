package com.rishi.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

	private ApiErrorResponse buildError(HttpStatus status, String message, HttpServletRequest request) {
        return new ApiErrorResponse(
                status.value(),
                message,
                request.getRequestURI(),
                LocalDateTime.now()
        );
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ApiErrorResponse handleBadCredentials(BadCredentialsException ex, HttpServletRequest request) {
        return buildError(HttpStatus.UNAUTHORIZED, "Invalid Credentials", request);
    }

    @ExceptionHandler(ExpiredJwtException.class)
    public ApiErrorResponse handleExpiredJwt(ExpiredJwtException ex, HttpServletRequest request) {
        return buildError(HttpStatus.UNAUTHORIZED, "Token Expired", request);
    }

    @ExceptionHandler(JwtException.class)
    public ApiErrorResponse handleJwtException(JwtException ex, HttpServletRequest request) {
        return buildError(HttpStatus.FORBIDDEN, "Invalid Token", request);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ApiErrorResponse handleAccessDenied(AccessDeniedException ex, HttpServletRequest request) {
        return buildError(HttpStatus.FORBIDDEN, "Access Denied", request);
    }

    @ExceptionHandler(Exception.class)
    public ApiErrorResponse handleGeneralException(Exception ex, HttpServletRequest request) {
        return buildError(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong!", request);
    }
}

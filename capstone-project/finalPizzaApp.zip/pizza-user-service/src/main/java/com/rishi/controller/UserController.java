package com.rishi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rishi.dto.MenuItemDTO;
import com.rishi.feign.AdminMenuClient;
import com.rishi.model.User;
import com.rishi.repository.UserRepository;
import com.rishi.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller  // since thyemleaf
public class UserController {

	@Autowired
    private UserService userService;
	
	@Autowired
	private AdminMenuClient adminMenuClient;
	
	@Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
	
	// navigate to login page
	@GetMapping("/")
    public String home() {
        return "login";
    }
	

	
	
//	// old code
//	// login logic
//	@PostMapping("/login")
//    public String login(@RequestParam String username,
//                        @RequestParam String password,
//                        Model model) {
//
//        User user = userService.login(username, password);
//
//        if (user != null) {
//            model.addAttribute("name", user.getUsername());
//            return "user-home"; // redirect to dashboard
//        }
//        model.addAttribute("error", "Invalid Credentials!");
//        return "login";
//    }
	
	// login logic
	@PostMapping("/login")
	public String login(@RequestParam String username,
	                    @RequestParam String password,
	                    HttpSession session,
	                    Model model) {

	    User user = userRepository.findByUsername(username);

	    if (user != null && passwordEncoder.matches(password, user.getPassword())) {
	        session.setAttribute("userId", user.getId());  // Important
	        model.addAttribute("name", user.getUsername());
	        return "user-home";    // redirect to dashboard
	    }

	    model.addAttribute("error", "Invalid Credentials!");
	    return "login";
	}

	
	
	
	
	
	// navigate to register page with new User obj
	@GetMapping("/register")
    public String showRegisterPage(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }
	
	
	// register logic
	@PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        userService.register(user);
        model.addAttribute("message", "Registration Successful! Please login.");
        return "login";
    }
	
	
	
	// using feign client to get all menu items data from admin-service
	@GetMapping("/menu")
	public String give(Model model){
		List<MenuItemDTO> items = adminMenuClient.getAllMenuItems();
		model.addAttribute("items", items);
		return "menu";
	}

	// User Home Page
	@GetMapping("/userhome")
	public String UserHomePage() {
		return "user-home";
	}
}

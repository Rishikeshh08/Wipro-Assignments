package com.rishi.controller;

import java.util.ArrayList; 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rishi.dto.MenuItemDTO;
import com.rishi.feign.AdminMenuClient;
import com.rishi.model.Order;
import com.rishi.model.OrderItem;
import com.rishi.model.OrderStatus;
//import com.rishi.model.User;
import com.rishi.repository.OrderItemRepository;
import com.rishi.repository.OrderRepository;
//import com.rishi.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
    private AdminMenuClient adminMenuClient;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;
    
//    @Autowired
//    private UserRepository userRepository;

	//private Long currentUserId = 1L; // Temporarily static till login-session added
	
	
	
	// Adding Order logic
	@PostMapping("/add")
	public String addOrder(@RequestParam Long itemId, Model model, HttpSession session) {  // 1. receive itemId
		
		// 2. fetch menuItem (Pizza)
		MenuItemDTO menuItem = adminMenuClient.getAllMenuItems()
                .stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElse(null);
		
		if (menuItem == null) {
            model.addAttribute("error", "Item not found");
            return "menu";
        }
		
		// Get Logged-in User from JWT
		Long userId = (Long) session.getAttribute("userId");
//	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//	    String username = auth.getName();
//	    User user = userRepository.findByUsername(username);
		
		// 3. Create new Order (only one item for now)
        Order order = new Order();
        order.setUserId(userId);
        order.setStatus(OrderStatus.PLACED);
        order.setItems(new ArrayList<>());
        Order savedOrder = orderRepository.save(order);
        
        // 4. create new OrderItem 
        OrderItem item = new OrderItem();
        item.setOrder(savedOrder);
        item.setMenuItemName(menuItem.getName());
        item.setPrice(menuItem.getPrice());
        item.setQuantity(1);
        orderItemRepository.save(item);
        
        // 4. update TotalAmount in Order
        List<OrderItem> orderItems = new ArrayList<>();
        orderItems.add(item);
        savedOrder.setItems(orderItems);
        savedOrder.setTotalAmount(menuItem.getPrice());
        orderRepository.save(savedOrder);
        
        // 5. show success page
        model.addAttribute("order", savedOrder);
        return "order-success";
	}
	
	
	// sending all orders data - will be used by admin-service to show on page + revenue
	@GetMapping("/api/all")
	@ResponseBody
	public List<Order> getAllOrders() {
	    return orderRepository.findAll();
	}
	
	// updating status logic -sending string - will be used by admin-service for accept/reject order
	@PutMapping("/api/update-status/{orderId}")
	@ResponseBody
	public String updateOrderStatus(@PathVariable Long orderId,
	                               @RequestParam String status) {
	    Order order = orderRepository.findById(orderId).orElse(null);
	    if (order == null) return "Order not found";

	    order.setStatus(OrderStatus.valueOf(status));
	    orderRepository.save(order);

	    return "Status updated to: " + status;
	}
	
	
	
	
//	// old 
//	// get orders by userId - to display orders history of particular user (userId)
//	@GetMapping("/my-orders")
//	public String myOrders(Model model) {
//		//get userid from jwt
//		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//	    String username = auth.getName();
//	    User user = userRepository.findByUsername(username);
//	    
//	    List<Order> orders = orderRepository.findByUserId(user.getId());
//	    model.addAttribute("orders", orders);
//	    return "order-list";
//	}

	@GetMapping("/my-orders")
	public String myOrders(HttpSession session, Model model) {

	    Long userId = (Long) session.getAttribute("userId");
	    if (userId == null) {
	        return "redirect:/";
	    }

	    List<Order> orders = orderRepository.findByUserId(userId);
	    model.addAttribute("orders", orders);
	    return "order-list";
	}

	
	
	
	
//	// old
//	// cancel order logic - change status to CANCELLED
//	@GetMapping("/cancel/{orderId}")
//	public String cancelOrder(@PathVariable Long orderId, Model model) {
//		// userId from jwt
//		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//		String username = auth.getName();
//		User user = userRepository.findByUsername(username);
//		
//	    Order order = orderRepository.findById(orderId).orElse(null);
//
//	    if (order != null &&
//	    	    order.getUserId().equals(user.getId()) && 	 // Users can cancel only their own orders
//	    	    order.getStatus() == OrderStatus.PLACED) {
//
//	    	    order.setStatus(OrderStatus.CANCELLED);
//	    	    orderRepository.save(order);
//	    }
//	    return "redirect:/order/my-orders";
//	}
	
	@GetMapping("/cancel/{orderId}")
	public String cancelOrder(@PathVariable Long orderId, HttpSession session) {

	    Long userId = (Long) session.getAttribute("userId");
	    if (userId == null) {
	        return "redirect:/";
	    }

	    Order order = orderRepository.findById(orderId).orElse(null);

	    if (order != null &&
	        order.getUserId().equals(userId) &&
	        order.getStatus() == OrderStatus.PLACED) {

	        order.setStatus(OrderStatus.CANCELLED);
	        orderRepository.save(order);
	    }

	    return "redirect:/order/my-orders";
	}


	
	
	
	
	// view bill logic - if order present go to bill page else to orders list
	@GetMapping("/bill/{orderId}")
	public String bill(@PathVariable Long orderId, Model model) {
	    Order order = orderRepository.findById(orderId).orElse(null);
	    if (order == null) {
	        model.addAttribute("error", "Order not found!");
	        return "order-list";
	    }
	    model.addAttribute("order", order);
	    return "bill";
	}


}

package com.rishi.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.rishi.dto.MenuItemDTO;

@FeignClient(name="pizza-admin-service")
public interface AdminMenuClient {
	
	@GetMapping("/menu/api/all")
    List<MenuItemDTO> getAllMenuItems();
}

package com.rishi.service;

//import java.util.List; 

//import com.rishi.model.MenuItem;
import com.rishi.model.User;

public interface UserService {
	
	User register(User user);
	
	User login(String username, String password);
	
	
}

package com.rishi.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}

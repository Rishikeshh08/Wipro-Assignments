package com.rishi.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.rishi.admin.model.Admin;
import com.rishi.admin.service.AdminService;

@Controller
public class AdminController {

	@Autowired
    private AdminService adminService;
	
	// go to login page
	@GetMapping("/")
    public String loginPage() {
        return "admin-login";
    }
	
	// login - core logic
	@PostMapping("/login")
    public String adminLogin(@RequestParam String username,
                             @RequestParam String password,
                             Model model) {

        Admin admin = adminService.login(username, password);

        if (admin != null) {
            model.addAttribute("name", admin.getUsername());
            return "admin-dashboard";
        }

        model.addAttribute("error", "Invalid Credentials!");
        return "admin-login";
    }
	
	@GetMapping("/dashboard")
	public String dashboard() {
		return "admin-dashboard";
	}
	

}

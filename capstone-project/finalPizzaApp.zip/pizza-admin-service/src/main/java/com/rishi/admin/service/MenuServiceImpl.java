package com.rishi.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rishi.admin.model.MenuItem;
import com.rishi.admin.repository.MenuItemRepository;

@Service
public class MenuServiceImpl implements MenuService{

	@Autowired
    private MenuItemRepository menuItemRepository;

    @Override
    public MenuItem save(MenuItem item) {
        return menuItemRepository.save(item);
    }

    @Override
    public List<MenuItem> getAll() {
        return menuItemRepository.findAll();
    }

    @Override
    public MenuItem getById(Long id) {
        return menuItemRepository.findById(id).orElse(null);
    }

    @Override
    public void delete(Long id) {
        menuItemRepository.deleteById(id);
    }
}

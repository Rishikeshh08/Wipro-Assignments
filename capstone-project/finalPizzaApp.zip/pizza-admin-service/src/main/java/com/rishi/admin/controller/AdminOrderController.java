package com.rishi.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rishi.admin.dto.OrderDTO;
import com.rishi.admin.feign.OrderClient;

@Controller
public class AdminOrderController {
	
	@Autowired
    private OrderClient orderClient;
	
	// using feign client to get all orders data from user-service
	@GetMapping("/orders")
    public String viewOrders(Model model) {
        List<OrderDTO> orders = orderClient.getAllOrders();
        model.addAttribute("orders", orders);
        return "admin-orders";
    }
	
	// using feign client to update status to ACCEPTED
	@GetMapping("/orders/accept/{orderId}")
	public String acceptOrder(@PathVariable Long orderId) {
	    orderClient.updateStatus(orderId, "ACCEPTED");
	    return "redirect:/orders";
	}

	// using feign client to update status to REJECTED
	@GetMapping("/orders/reject/{orderId}")
	public String rejectOrder(@PathVariable Long orderId) {
	    orderClient.updateStatus(orderId, "REJECTED");
	    return "redirect:/orders";
	}

}

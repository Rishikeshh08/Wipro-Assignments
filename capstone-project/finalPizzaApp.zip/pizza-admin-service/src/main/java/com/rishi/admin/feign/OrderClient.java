package com.rishi.admin.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rishi.admin.dto.OrderDTO;


@FeignClient(name="pizza-user-service")
public interface OrderClient {
	
	@GetMapping("/order/api/all")
	public List<OrderDTO> getAllOrders();
	
	@PutMapping("/order/api/update-status/{orderId}")
	String updateStatus(@PathVariable Long orderId,
	                    @RequestParam String status);

}

package com.rishi.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rishi.admin.model.MenuItem;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long>{

}

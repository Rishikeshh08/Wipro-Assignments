package com.rishi.admin.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.rishi.admin.dto.OrderDTO;
import com.rishi.admin.feign.OrderClient;

@Controller
public class RevenueController {

	@Autowired
    private OrderClient orderClient;
	
	// using feign client to get all order + filter + sum
	@GetMapping("/revenue")
    public String revenuePage(Model model) {

        List<OrderDTO> orders = orderClient.getAllOrders();

        // Filter 
        double totalRevenue = orders.stream()
                .filter(o -> o.getStatus().equals("ACCEPTED") 
                          || o.getStatus().equals("DELIVERED"))
                .mapToDouble(o -> o.getTotalAmount() != null ? o.getTotalAmount() : 0)
                .sum();

        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("month", LocalDate.now().getMonth().toString());

        return "revenue";
    }
}

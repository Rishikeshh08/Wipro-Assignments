package com.rishi.admin.service;

import com.rishi.admin.model.Admin;

public interface AdminService {
	Admin login(String username, String password);
}

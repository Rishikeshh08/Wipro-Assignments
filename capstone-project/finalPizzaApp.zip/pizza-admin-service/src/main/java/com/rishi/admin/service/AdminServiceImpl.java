package com.rishi.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.rishi.admin.model.Admin;
import com.rishi.admin.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
    private AdminRepository adminRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
    public Admin login(String username, String password) {
        Admin admin = adminRepository.findByUsername(username);

        if (admin != null && passwordEncoder.matches(password, admin.getPassword())) {
            return admin;
        }
        return null;
    }
}

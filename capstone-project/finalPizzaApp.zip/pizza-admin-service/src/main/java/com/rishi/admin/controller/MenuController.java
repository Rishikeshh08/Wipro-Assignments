package com.rishi.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rishi.admin.model.MenuItem;
import com.rishi.admin.service.MenuService;

@Controller
@RequestMapping("/menu")
public class MenuController {

	@Autowired
    private MenuService menuService;
	
	// show menu list
	@GetMapping("/list")
    public String listMenu(Model model) {
        model.addAttribute("items", menuService.getAll());
        return "menu-list";
    }
	
	// add menu item - go fill form first
	@GetMapping("/add")
    public String addMenuForm(Model model) {
        model.addAttribute("item", new MenuItem());
        return "menu-form";
    }
	
	// core logic of - ADD MENU ITEM + EDIT MENU ITEM
	@PostMapping("/save")
    public String save(@ModelAttribute MenuItem item) {        // ("item")
        menuService.save(item);
        return "redirect:/menu/list";
    }
	
	// edit menu item - go fill form first
	@GetMapping("/edit/{id}")
    public String editMenu(@PathVariable Long id, Model model) {
        model.addAttribute("item", menuService.getById(id));
        return "menu-form";
    }
	
	// core logic - DELETE MENU ITEM
	@GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        menuService.delete(id);
        return "redirect:/menu/list";
    }
	
	// sending all menu items to user using feign client
	@GetMapping("/api/all")
	@ResponseBody    // data goes directly to browser as JSON
	public List<MenuItem> getAllMenuItemsAPI(){
		return menuService.getAll();
	}
}

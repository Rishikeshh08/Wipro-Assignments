package com.rishi.admin.dto;

import java.util.List;

import lombok.Data;

@Data
public class OrderDTO {
	private Long id;
    private Long userId;
    private Double totalAmount;
    private String status;
    private List<OrderItemDTO> items;
}

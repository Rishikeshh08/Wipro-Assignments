package com.rishi.admin.dto;

import lombok.Data;

@Data
public class OrderItemDTO {
	private String menuItemName;
    private Double price;
    private Integer quantity;
}

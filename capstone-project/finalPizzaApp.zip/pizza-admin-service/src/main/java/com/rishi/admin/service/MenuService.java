package com.rishi.admin.service;

import java.util.List;

import com.rishi.admin.model.MenuItem;

public interface MenuService {
	MenuItem save(MenuItem item);
    List<MenuItem> getAll();
    MenuItem getById(Long id);
    void delete(Long id);
}
